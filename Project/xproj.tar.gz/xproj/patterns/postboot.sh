#!/bin/bash

psql -f /opt/patroni/postboot.sql
