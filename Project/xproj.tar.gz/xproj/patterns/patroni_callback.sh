#!/bin/bash

readonly cb_name=$1
readonly role=$2
readonly scope=$3

VIR=virt_ip
VIB=virt_brd
IFNAME=virt_if
IFMASK=virt_msk
 
function usage() {
    echo "Usage: $0 <on_start|on_stop|on_role_change> <role> <scope>";
    exit 1;
}
 
echo "this is patroni callback $cb_name $role $scope"
 
case $cb_name in
    on_stop)
        if [[ ! -z  $(ip address | awk '/'$VIR'/{print $0}') ]]; then
            sudo ip addr del $VIR/$IFMASK dev $IFNAME;
            #sudo arping -q -A -c 1 -I $IFNAME -S  $VIR  $VIR
            sudo iptables -F
        fi    
        ;;
    on_start|on_role_change|on_schedule)
        if [[ $role == 'master' ]] || [[ $role == 'primary' ]]; then
            if [[ -z  $(ip address | awk '/'$VIR'/{print $0}') ]]; then
                sudo ip addr add $VIR/$IFMASK brd $VIB dev $IFNAME;
                #sudo arping -q -U -c 2 -I $IFNAME -S $VIR $VIR;
                #sudo arping -q -A -c 2 -I $IFNAME -S $VIR $VIR;
                sudo arping -c 2 -U -I $IFNAME -s $VIR $VIR;
                sudo arping -c 2 -A -I $IFNAME -s $VIR $VIR;
                sudo iptables -F
            fi    
        elif [[ $role == 'slave' ]] || [[ $role == 'replica' ]] || [[ $role == 'logical' ]]; then
            if [[ ! -z  $(ip address | awk '/'$VIR'/{print $0}') ]]; then
                sudo ip addr del $VIR/$IFMASK dev $IFNAME
                #sudo arping -q -A -c 1 -I $IFNAME -S $VIR $VIR
                sudo iptables -F
            fi    
        fi
        ;; 
    *)
        usage
        ;;
esac
